#pragma once

#include <iostream>
#include <memory>
#include "definitions.h"

enum { C_X_MAJOR, C_Y_MAJOR, CPP_X_MAJOR, CPP_Y_MAJOR };


class array
{
public:
	array(const int& _n_xs, const int& _n_ys, std::ostream* _output) : data{ nullptr } {};
	array(const array& _in) = delete;
	array& operator=(const array& _in) = delete;
	~array() {
		deallocate();
	}
	void write_data(const int& _xhi, const int& _yhi);
	void write_data();
	virtual double& operator()(int x, int y) = 0;
	//double operator()(int& x, int& y) const;
	std::unique_ptr<double []> data_modern;
	double** data;

protected:
	int allocation_mode;
	int n_xs, n_ys;
	std::ostream* output;
	virtual void allocate() = 0;
	virtual void deallocate() = 0;
	void bounds_check(int x, int y) const;
	double& operator_c_cpp_x_major(int x, int y);
	double& operator_c_cpp_y_major(int x, int y);
	double& operator_modern_x_major(int x, int y);
	double& operator_modern_y_major(int x, int y);
};

