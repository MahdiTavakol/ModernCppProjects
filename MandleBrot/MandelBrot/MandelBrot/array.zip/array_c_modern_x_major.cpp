#include "array_c_modern_x_major.h"

array_c_modern_x_major::array_c_modern_x_major(const int& _n_xs, const int& _n_ys, std::ostream* _output)
	: array{ _n_xs, _n_ys, _output } {
	allocate();
	output = _output;
}

double& array_c_modern_x_major::operator()(int x, int y)
{
	return operator_modern_x_major(x, y);
}

void array_c_modern_x_major::allocate()
{
	data_modern = std::make_unique<double[]>(n_xs * n_ys);
}

void array_c_modern_x_major::deallocate()
{
	// No explicit deallocation needed for std::unique_ptr
}

