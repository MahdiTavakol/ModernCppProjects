#pragma once

#include "Ref.h"
#include "Engine.h"

class Neighbor : public Ref {
public:
	Neighbor(std::vector<std::string> args_);
	Neighbor();
	Neighbor(double neighbor_cutoff_);
	virtual void injectDependencies(Engine& engine_) override;
	virtual void init();
	virtual void update() {}
	virtual void getNeighborList(int& nNeigh_, int*& neighList_, int*& firstNeigh_, int*& numNeigh_);
	double getCutoff() const { return neighbor_cutoff; }

protected:
	// Particles pointer
	Particles* particles;
	int nNeigh;
	std::vector<int> neighList, numNeigh, firstNeigh;
	double neighbor_cutoff;
};