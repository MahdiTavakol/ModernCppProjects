#ifndef MATERIAL_H
#define MATERIAL_H


#include "../Shared/rtweekend.h"

#include "../Types/ray.h"
#include "../Types/color.h"
#include "../Geometry/texture.h"
#include "../Algorithms/hit_record.h"



class material
{
public:
	virtual ~material() = default;


	virtual color emitted(double _u, double _v, const point3& _p) const
	{
		return color(0, 0, 0);
	}

	virtual bool scatter(const ray& r_in, const hit_record& rec, color& attenuation, ray& scattered) const
	{
		return false;
	}

	virtual bool is_equal( const material& _second) const = 0;

	virtual bool compare(material* _rhs, const double tol_) const
	{
		std::cout << "The compare function has not been implemented yet " << std::endl;
		return true;
	}

	bool operator==(const material& _second) {
		return (typeid(*this) == typeid(_second)) && (is_equal(_second));
	}
};

class general : public material
{
public:
	general(const color& _albedo, const double& _shininess,
		const double& _d, const double& _Tr, const color& _Tf, const color _Ks) :
		albedo(_albedo), shininess(_shininess), d(_d), Tr(_Tr), Tf(_Tf), Ks(_Ks)
	{
	}


	bool scatter(const ray& r_in, const hit_record& rec, color& attenuation, ray& scattered) const override
	{
		// Calculate the effective transparency based on d (dissolve) and Tr (transparency)
		double effective_transparency = (1.0 - d) * Tr;

		// Reflect the incoming ray based on the hit normal
		vec3 reflected = reflect(r_in.direction(), rec.normal);

		// Make reflection a bit fuzzier based on `fuzz` parameter
		//reflected += fuzz * random_unit_vector(); // Adjusted to fuzziness

		// Control sharpness of reflection based on shininess (Ns)
		reflected = reflected * (1.0 - shininess / 100.0) + rec.normal * (shininess / 100.0);

		// Scatter the ray with the adjusted direction
		scattered = ray(rec.p, reflected, r_in.time());

		// Apply attenuation based on effective transparency
		// You may choose to mix the albedo and some transparency effect
		attenuation = albedo * (1.0 - effective_transparency) + Tf * effective_transparency;

		return true;
	}

	bool is_equal(const material& _second) const override {
		const general* o = dynamic_cast<const general*>(&_second);
		return o && (albedo == o->albedo) && (shininess == o->shininess) &&
			(d == o->d) && (Tr == o->Tr) && (Tf == o->Tf) && (Ks == o->Ks);
	}

	bool compare(material* rhs_, const double tol_) const override
	{
		general* o = dynamic_cast<general*>(rhs_);
		if (!o) {
			std::cout << "Material type mismatch" << std::endl;
			return true;
		}
		if (std::abs(shininess - o->shininess) >= tol_)
			return true;
		if (std::abs(d - o->d) >= tol_)
			return true;
		color deltaAlb = albedo - o->albedo;
		color deltaKa = Ka - o->Ka;
		color deltaKs = Ks - o->Ks;
		color deltaTf = Tf - o->Tf;
		double dAlbLength = deltaAlb.length();
		double dKaLength = deltaKa.length();
		double dKsLength = deltaKs.length();
		double dTfLength = deltaTf.length();
		if (dAlbLength >= tol_ ||
			dKaLength  >= tol_ ||
			dKsLength  >= tol_ ||
			dTfLength  >= tol_)
			return true;
		return false;
	}



private:
	color albedo;
	double shininess;
	double d, Tr;
	color Ka, Ks, Tf;
};


class lambertian : public material
{
public:
	lambertian(const color& _albedo) : tex(std::make_unique<solid_color>(_albedo)) {}
	lambertian(std::unique_ptr<texture> _tex) :
		tex{ std::move(_tex) }
	{}


	bool scatter(const ray& r_in, const hit_record& rec, color& attenuation, ray& scattered) const override
	{
		auto scatter_direction = rec.normal + random_unit_vector();

		if (scatter_direction.near_zero())
			scatter_direction = rec.normal;
		scattered = ray(rec.p, scatter_direction, r_in.time());
		attenuation = tex->value(rec.u, rec.v, rec.p);
		return true;
	}

	bool is_equal(const material& _second) const override {
		const lambertian* o = dynamic_cast<const lambertian*>(&_second);
		return o && false;
		//return o && (*tex == *(o->tex)); 
	}

private:
	std::unique_ptr<texture> tex;
};

class metal : public material
{
public:
	metal() : albedo(vec3(0, 0, 0)), fuzz(1.0) {}

	metal(const color& _albedo, double _fuzz) : albedo(_albedo), fuzz(_fuzz) {}



	bool scatter(const ray& r_in, const hit_record& rec, color& attenuation, ray& scattered) const override
	{
		vec3 reflected = reflect(r_in.direction(), rec.normal);
		reflected = unit_vector(reflected) + fuzz * random_unit_vector();
		scattered = ray(rec.p, reflected, r_in.time());
		attenuation = albedo;
		return true;
	}

	void return_params(color& _albedo, double& _fuzz)
	{
		_fuzz = fuzz;
		_albedo = albedo;
	}

	bool is_equal(const material& _second) const override {
		const metal* o = dynamic_cast<const metal*>(&_second);
		return o && (albedo == o->albedo) && (fuzz == o->fuzz);
	}

private:
	color albedo;
	double fuzz;
};

class dielectric : public material
{
public:
	dielectric(double _refraction_index) : refraction_index(_refraction_index) {}


	bool scatter(const ray& r_in, const hit_record& rec, color& attenuation, ray& scattered) const override
	{
		attenuation = color(1.0, 1.0, 1.0);
		double ri = rec.front_face ? (1.0 / refraction_index) : refraction_index;

		vec3 unit_direction = unit_vector(r_in.direction());
		double cos_theta = std::fmin(dot(-unit_direction, rec.normal), 1.0);
		double sin_theta = std::sqrt(1.0 - cos_theta * cos_theta);

		bool cannot_refract = ri * sin_theta > 1.0;
		vec3 direction;

		if (cannot_refract || reflectance(cos_theta, ri) > random_double())
			direction = reflect(unit_direction, rec.normal);
		else
			direction = refract(unit_direction, rec.normal, ri);

		scattered = ray(rec.p, direction, r_in.time());
		return true;
	}

	void return_params(double& _ref)
	{
		_ref = refraction_index;
	}

	bool is_equal(const material& _second) const override {
		const dielectric* o = dynamic_cast<const dielectric*>(&_second);
		return o && (refraction_index == o->refraction_index);
	}

private:
	double refraction_index;

	static double reflectance(double cosine, double refraction_index)
	{
		auto r0 = (1 - refraction_index) / (1 + refraction_index);
		r0 = r0 * r0;
		return r0 + (1 - r0) * std::pow((1 - cosine), 5);
	}
};


class diffuse_light : public material {
public:
	diffuse_light(std::unique_ptr<texture>& _tex) : tex{ std::move(_tex) } {}
	diffuse_light(const color& _emit) : tex{ std::make_unique<solid_color>(_emit) } {}


	color emitted(double _u, double _v, const point3& _p)  const override {
		return tex->value(_u, _v, _p);
	}

	bool is_equal(const material& _second) const override {
		const diffuse_light* o = dynamic_cast<const diffuse_light*>(&_second);
		return o && (tex == o->tex);
	}

private:
	std::unique_ptr<texture> tex;
};

class isotropic : public material
{
public:
	isotropic(const color& _albedo) : tex(std::make_unique<solid_color>(_albedo)) {}
	isotropic(std::unique_ptr<texture>& _tex) : tex{ std::move(_tex) } {}



	bool scatter(const ray& _r_in, const hit_record& _rec, color& _attenuation, ray& _scattered) const override
	{
		_scattered = ray(_rec.p, random_unit_vector(), _r_in.time());
		_attenuation = tex->value(_rec.u, _rec.v, _rec.p);
		return true;
	}

	bool is_equal(const material& _second) const override {
		const isotropic* o = dynamic_cast<const isotropic*>(&_second);
		return o && (tex == o->tex);
	}

private:
	std::unique_ptr<texture> tex;
};

#endif
